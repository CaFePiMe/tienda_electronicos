Tamaño de la ventana 1920 px x 1080 px
Botones adaptados para este tamaño de la ventana

COLORES:
Gradiente
azul claro:

R:0
G:113
B:186

azul oscuro:

R:27
G:20
B:100

fuentes tipográficas:
Metropolis family:
Thin
Light
Regular
Bold
ExtraBold
Black